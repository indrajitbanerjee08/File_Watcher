﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace FilewatcherService
{
    [JsonConverter(typeof(ResultConverter))]
    class ServiceInstanceResult
    {
        public string String { get; set; }
        public ServiceInstance ser { get; set; }
    }
}

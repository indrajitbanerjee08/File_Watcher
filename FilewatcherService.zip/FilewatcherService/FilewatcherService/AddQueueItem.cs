﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FilewatcherService
{
    class AddQueueItem
    {
        public  void AddItemToQueue(String Fullpath)
        {
            String AddQueueItemURI = "";
            if (FileWatcherService.Is_Cloud_Platform.ToUpper().Equals("Y"))
            {
                AddQueueItemURI = FileWatcherService.Orchestrator_Login_URL.Trim() + "/" + FileWatcherService.AccountForUserDict["accountLogicalName"] + "/" + FileWatcherService.ServiceAccountDetails["serviceInstanceLogicalName"] + "/odata/Queues/UiPathODataSvc.AddQueueItem";
            }
            else
            {
                AddQueueItemURI = FileWatcherService.Orchestrator_Login_URL.Trim() + "/odata/Queues/UiPathODataSvc.AddQueueItem";
            }

            HttpWebRequest AddQueueItemRequest = (HttpWebRequest)WebRequest.Create(AddQueueItemURI);

            AddQueueItemRequest.KeepAlive = false;
            AddQueueItemRequest.ProtocolVersion = HttpVersion.Version10;
            AddQueueItemRequest.Method = "POST";
            AddQueueItemRequest.ContentType = "application/json";
            AddQueueItemRequest.Headers.Add("Authorization", "Bearer " + FileWatcherService.TokenDict["accessToken"]);
            if (FileWatcherService.Is_Cloud_Platform.ToUpper().Equals("Y"))
            {
                AddQueueItemRequest.Headers.Add("X-UIPATH-TenantName", FileWatcherService.ServiceAccountDetails["serviceInstanceLogicalName"]);
            }
            //Fullpath.Replace(@"\\",@"\\\\");
            string output = Regex.Replace(Fullpath, @"\\", @"\\");
            Console.WriteLine("Full path-->" + output);
            FileWatcherService.requestBody = string.Format("{{\"itemData\":{{\"Priority\":\"Normal\",\"Name\":\"{0}\",\"SpecificContent\":{{ \"Folder_Path@odata.type\":\"String\",\"Folder_Path\":\"{1}\"}}}}}}", FileWatcherService.Queue_Name, output);
            //Console.WriteLine("REquest Body-->" + requestBody);
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] byte1 = encoding.GetBytes(FileWatcherService.requestBody);
            AddQueueItemRequest.ContentLength = byte1.Length;
            Stream newStream = AddQueueItemRequest.GetRequestStream();
            newStream.Write(byte1, 0, byte1.Length);
            try
            {
                AddQueueItemRequest.GetResponse().GetResponseStream();

                StreamReader httpWebStreamReader = new StreamReader(AddQueueItemRequest.GetResponse().GetResponseStream());
                String result = httpWebStreamReader.ReadToEnd();
                FileWatcherService.APIJsonResponse = result;


            }
            catch(System.Exception sysexcptn)
            {
                throw  new Exception(sysexcptn.Message+"::Queue Name improper");
            }



        }
    }
}

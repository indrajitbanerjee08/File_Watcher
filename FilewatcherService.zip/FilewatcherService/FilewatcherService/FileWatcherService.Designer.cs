﻿using System.Diagnostics;
using System.IO;

namespace FilewatcherService
{
    partial class FileWatcherService
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            // 
            // FileWatcherService
            // 
            this.ServiceName = "FileWatcherService";

        }
        private static void OnChanged(object source, FileSystemEventArgs e)
        {
            try
            {
                EventLog eventlog = new EventLog();
                eventlog.Source = "FilewatcherInfo_OnChanged";
                eventlog.WriteEntry($"File: {e.FullPath} {e.ChangeType}");
                TokenDict.Clear();
                AccountForUserDict.Clear();
                ServiceAccountDetails.Clear();
                ReleaseKeyDict.Clear();

                //Condition to check if Orch is On Prem or Cloud
                if (Is_Cloud_Platform.ToUpper().Equals("Y"))
                {
                    CloudAccessToken cloudAccessTokenInstance = new CloudAccessToken();
                    cloudAccessTokenInstance.GetCloudAcessToken();
                    AccountForUser accForUserInstance = new AccountForUser();
                    accForUserInstance.GetAccountForUser(TokenDict);
                    AllService getAllServiceInstance = new AllService();
                    getAllServiceInstance.GetAllServiceAccount(AccountForUserDict, TokenDict);
                }
                else
                {
                    OnPremiseToken onPremTokenInstance = new OnPremiseToken();
                    onPremTokenInstance.GetOnPremiseAccessToken();
                }

                //For Orch Feature 19.10 and above,item will be added to queue and job will be triggered automatically from Orchestrator.
                if (Is_Queue_Trigger_Enabled.ToUpper().Equals("Y"))
                {
                    AddQueueItem addQueueItem = new AddQueueItem();
                    addQueueItem.AddItemToQueue(e.FullPath);
                }
                else
                {
                    //If additionally path of file needs to be added to queue item and job to be started.
                    if (Is_Queue_Addition_Enabled.ToUpper().Equals("Y"))
                    {
                        AddQueueItem addQueueItem = new AddQueueItem();
                        addQueueItem.AddItemToQueue(e.FullPath);
                        ReleaseKeyFetch releaseKeyInstance = new ReleaseKeyFetch();
                        releaseKeyInstance.GetReleaseKey();
                        StartJob startJobInstance = new StartJob();
                        startJobInstance.StartProcess();
                    }
                    else
                    {
                        ReleaseKeyFetch releaseKeyInstance = new ReleaseKeyFetch();
                        releaseKeyInstance.GetReleaseKey();
                        StartJob startJobInstance = new StartJob();
                        startJobInstance.StartProcess();
                    }
                }
            }
            catch (System.Exception sysexcptn)
            {
                EventLog eventlog = new EventLog();
          
                eventlog.Source = "FilewatcherInfo_Error";
                eventlog.WriteEntry("Exception Occured due to "+sysexcptn.Message);

            }
        }


        #endregion
    }
}

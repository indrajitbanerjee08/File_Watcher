﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace FilewatcherService
{
    class CloudAccessToken
    {
        public void GetCloudAcessToken()
        {
            HttpWebRequest refreshTokeRequest = (HttpWebRequest)WebRequest.Create("https://account.uipath.com/oauth/token");
            refreshTokeRequest.KeepAlive = false;
            refreshTokeRequest.ProtocolVersion = HttpVersion.Version10;
            refreshTokeRequest.Method = "POST";
            refreshTokeRequest.ContentType = "application/json";
            //Console.WriteLine("refresh token" + servRefresh_token);
            FileWatcherService.requestBody = string.Format("{{\"grant_type\":\"refresh_token\",\"client_id\":\"{0}\",\"refresh_token\":\"{1}\"}}", FileWatcherService.Client_Id, FileWatcherService.Refresh_token);
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] byte1 = encoding.GetBytes(FileWatcherService.requestBody);
            refreshTokeRequest.ContentLength = byte1.Length;
            Stream newStream = refreshTokeRequest.GetRequestStream();
            newStream.Write(byte1, 0, byte1.Length);

            try
            {
                HttpWebResponse myHttpWebResponse = (HttpWebResponse)refreshTokeRequest.GetResponse();

                if (myHttpWebResponse.StatusCode == HttpStatusCode.OK)
                {
                    StreamReader httpWebStreamReader = new StreamReader(refreshTokeRequest.GetResponse().GetResponseStream());
                    String result = httpWebStreamReader.ReadToEnd();
                    FileWatcherService.APIJsonResponse = result;




                    using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(FileWatcherService.APIJsonResponse)))
                    {
                        // Deserialization from JSON  
                        DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(AcessToken));
                        AcessToken bsObj2 = (AcessToken)deserializer.ReadObject(ms);
                        Console.WriteLine("acess token is-->: " + bsObj2.access_token); // Name: C-sharpcorner
                        Console.WriteLine("id token is--> " + bsObj2.id_token);

                        FileWatcherService.TokenDict.Add("accessToken", bsObj2.access_token);
                        FileWatcherService.TokenDict.Add("idToken", bsObj2.id_token);


                    }
                    refreshTokeRequest.GetResponse().Close();
                    httpWebStreamReader.Close();
                }

            }
            catch (System.Exception sysexcptn)
            {
                throw new Exception(sysexcptn.Message+"::Client Id/Refresh Token mismatch");
            }

        }
    }
}

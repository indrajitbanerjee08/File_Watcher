﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace FilewatcherService
{
    [DataContract]
    class OnPremiseAccessToken
    {
        [DataMember]
        public string result { get; set; }
        [DataMember]
        public object targetUrl { get; set; }
        [DataMember]
        public bool success { get; set; }
        [DataMember]
        public object error { get; set; }
        [DataMember]
        public bool unAuthorizedRequest { get; set; }
        [DataMember]
        public bool __abp { get; set; }
    }
}

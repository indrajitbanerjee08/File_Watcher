﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FilewatcherService
{
    class StartJob
    {
        public void StartProcess()
        {
            try
            {
                String StartJobURI = "";
                if (FileWatcherService.Is_Cloud_Platform.ToUpper().Equals("Y"))
                {
                    StartJobURI = FileWatcherService.Orchestrator_Login_URL.Trim() + "/" + FileWatcherService.AccountForUserDict["accountLogicalName"] + "/" + FileWatcherService.ServiceAccountDetails["serviceInstanceLogicalName"] + "/odata/Jobs/UiPath.Server.Configuration.OData.StartJobs";
                }
                else
                {
                    StartJobURI = FileWatcherService.Orchestrator_Login_URL.Trim() + "/odata/Jobs/UiPath.Server.Configuration.OData.StartJobs";
                }
                HttpWebRequest StartJobrequest = (HttpWebRequest)WebRequest.Create(StartJobURI);
                StartJobrequest.KeepAlive = false;
                StartJobrequest.ProtocolVersion = HttpVersion.Version10;
                StartJobrequest.Method = "POST";
                StartJobrequest.ContentType = "application/json";
                StartJobrequest.Headers.Add("Authorization", "Bearer " + FileWatcherService.TokenDict["accessToken"]);
                if (FileWatcherService.Is_Cloud_Platform.ToUpper().Equals("Y"))
                {
                    StartJobrequest.Headers.Add("X-UIPATH-TenantName", FileWatcherService.ServiceAccountDetails["serviceInstanceLogicalName"]);
                }
                FileWatcherService.requestBody = string.Format("{{\"startInfo\":{{\"ReleaseKey\":\"{0}\",\"Strategy\":\"All\",\"Source\":\"Manual\"}}}}", FileWatcherService.ReleaseKeyDict["Release_Key"]);
                ASCIIEncoding encoding = new ASCIIEncoding();
                byte[] byte1 = encoding.GetBytes(FileWatcherService.requestBody);
                StartJobrequest.ContentLength = byte1.Length;
                Stream newStream = StartJobrequest.GetRequestStream();
                newStream.Write(byte1, 0, byte1.Length);
                HttpWebResponse myHttpWebResponse = (HttpWebResponse)StartJobrequest.GetResponse();

                

                StreamReader httpWebStreamReader = new StreamReader(StartJobrequest.GetResponse().GetResponseStream());
                String result = httpWebStreamReader.ReadToEnd();
                FileWatcherService.APIJsonResponse = result;
                Console.WriteLine(FileWatcherService.APIJsonResponse);
                EventLog eventlog = new EventLog();
                eventlog.Source = "FilewatcherInfo_StartJob";
                eventlog.WriteEntry(FileWatcherService.APIJsonResponse);
                StartJobrequest.GetResponse().Close();
                httpWebStreamReader.Close();


            }
            catch (SystemException sysexcptn)
            {
                EventLog eventlog = new EventLog();
                eventlog.Source = "FilewatcherInfo_Error";
                eventlog.WriteEntry("Exception Occured due to " + sysexcptn.Message + "The stack trace is-->" + sysexcptn.StackTrace);
            }
        }
    }
}

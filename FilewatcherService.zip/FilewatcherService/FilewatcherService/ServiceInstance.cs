﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using Newtonsoft.Json;


namespace FilewatcherService
{
    [DataContract]
    class ServiceInstance
    {
        [DataMember]
        [JsonProperty("serviceInstanceName")]
        public string serviceInstanceName { get; set; }

        [DataMember]
        [JsonProperty("serviceInstanceLogicalName")]
        public string serviceInstanceLogicalName { get; set; }

        [DataMember]
        [JsonProperty("serviceType")]
        public string serviceType { get; set; }

        [DataMember]
        [JsonProperty("serviceUrl")]
        public string serviceUrl { get; set; }

        [DataMember]
        [JsonProperty("serviceState")]
        public string serviceState { get; set; }

        [DataMember]
        [JsonProperty("userRolesInService")]
        public List<string> userRolesInService { get; set; }
    }
}

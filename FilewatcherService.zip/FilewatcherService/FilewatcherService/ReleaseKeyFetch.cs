﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace FilewatcherService
{
    class ReleaseKeyFetch
    {
        public  void GetReleaseKey()
        {
            String releaseKeyUri = "";
            if (FileWatcherService.Is_Cloud_Platform.ToUpper().Equals("Y"))
            {
                // releaseKeyUri = FileWatcherService.Orchestrator_Login_URL.Trim() + "/" + FileWatcherService.AccountForUserDict["accountLogicalName"] + "/" + FileWatcherService.ServiceAccountDetails["serviceInstanceLogicalName"] + "/odata/Releases?$filter= EnvironmentName eq '" + FileWatcherService.Environment_Name + "' & ProcessKey eq '" + FileWatcherService.Process_Name + "'";
                releaseKeyUri = FileWatcherService.Orchestrator_Login_URL.Trim() + "/" + FileWatcherService.AccountForUserDict["accountLogicalName"] + "/" + FileWatcherService.ServiceAccountDetails["serviceInstanceLogicalName"] + "/odata/Releases?$filter= ProcessKey eq '" + FileWatcherService.Process_Name + "' & EnvironmentName eq '" + FileWatcherService.Environment_Name + "'";
            }
            else
            {
                releaseKeyUri = FileWatcherService.Orchestrator_Login_URL.Trim() + "/odata/Releases?$filter= EnvironmentName eq '" + FileWatcherService.Environment_Name + "' & ProcessKey eq '" + FileWatcherService.Process_Name + "'";
            }
            HttpWebRequest ReleaseKeyRequest = (HttpWebRequest)WebRequest.Create(releaseKeyUri);
            //HttpUtility.UrlDecode(ReleaseKeyRequest.Address.AbsoluteUri);
            ReleaseKeyRequest.KeepAlive = false;
            ReleaseKeyRequest.ProtocolVersion = HttpVersion.Version10;
            ReleaseKeyRequest.Method = "GET";
            ReleaseKeyRequest.ContentType = "application/json";
            ReleaseKeyRequest.Headers.Add("Authorization", "Bearer " + FileWatcherService.TokenDict["accessToken"]);
            if (FileWatcherService.Is_Cloud_Platform.ToUpper().Equals("Y"))
            {
                ReleaseKeyRequest.Headers.Add("X-UIPATH-TenantName", FileWatcherService.ServiceAccountDetails["serviceInstanceLogicalName"]);
            }

            try
            {
                HttpWebResponse myHttpWebResponse = (HttpWebResponse)ReleaseKeyRequest.GetResponse();
                if (myHttpWebResponse.StatusCode == HttpStatusCode.OK)
                {

                    StreamReader httpWebStreamReader = new StreamReader(ReleaseKeyRequest.GetResponse().GetResponseStream());
                    String result = httpWebStreamReader.ReadToEnd();
                    FileWatcherService.APIJsonResponse = result;

                    ReleaseKeyRoot releaseKeyService = JsonConvert.DeserializeObject<ReleaseKeyRoot>(FileWatcherService.APIJsonResponse);
                    if (releaseKeyService.OdataCount == 0)
                    {
                        throw new Exception("Release Key Could not be fetched due to Process/Environment name mismatch.");
                    }
                    else
                    {
                        FileWatcherService.ReleaseKeyDict.Add("Release_Key", releaseKeyService.Value[0].Key);
                        ReleaseKeyRequest.GetResponse().Close();
                        httpWebStreamReader.Close();
                    }
                        
                }
            }
            catch(System.Exception sysexcptn)
            {
                throw new Exception(sysexcptn.Message+"::Process/Environment name improper.");
            }

        }
    }
}

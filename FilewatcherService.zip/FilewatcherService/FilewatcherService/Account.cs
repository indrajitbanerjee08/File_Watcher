﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace FilewatcherService
{
    [DataContract]
    class Account
    {
        [DataMember]
        public string accountName { get; set; }
        [DataMember]
        public string accountLogicalName { get; set; }

        [DataMember]
        public string userEmail { get; set; }

        [DataMember]
        public List<Account> accounts { get; set; }
    }
}

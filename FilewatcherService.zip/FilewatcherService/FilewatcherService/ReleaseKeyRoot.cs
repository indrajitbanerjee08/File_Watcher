﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Globalization;

namespace FilewatcherService
{
    public partial class ReleaseKeyRoot
    {
        [JsonProperty("@odata.context")]
        public Uri OdataContext { get; set; }

        [JsonProperty("@odata.count")]
        public long OdataCount { get; set; }

        [JsonProperty("value")]
        public Value[] Value { get; set; }
    }

    public partial class Value
    {
        [JsonProperty("Key")]
        public string Key { get; set; }

        [JsonProperty("ProcessKey")]
        public string ProcessKey { get; set; }

        [JsonProperty("ProcessVersion")]
        public string ProcessVersion { get; set; }

        [JsonProperty("IsLatestVersion")]
        public bool IsLatestVersion { get; set; }

        [JsonProperty("IsProcessDeleted")]
        public bool IsProcessDeleted { get; set; }

        [JsonProperty("Description")]
        public string Description { get; set; }

        [JsonProperty("Name")]
        public string Name { get; set; }

        [JsonProperty("EnvironmentId")]
        public long EnvironmentId { get; set; }

        [JsonProperty("EnvironmentName")]
        public string EnvironmentName { get; set; }

        [JsonProperty("InputArguments")]
        public object InputArguments { get; set; }

        [JsonProperty("Id")]
        public long Id { get; set; }

        [JsonProperty("Arguments")]
        public Arguments Arguments { get; set; }

        [JsonProperty("ProcessSettings")]
        public object ProcessSettings { get; set; }
    }

    public partial class Arguments
    {
        [JsonProperty("Input")]
        public object Input { get; set; }

        [JsonProperty("Output")]
        public object Output { get; set; }
    }

}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace FilewatcherService
{
    class AccountForUser
    {

        public  void GetAccountForUser(Dictionary<String, String> TokenDict)
        {

            HttpWebRequest getAccountForUserRequest = (HttpWebRequest)WebRequest.Create(FileWatcherService.Orchestrator_Login_URL.Trim() + "/cloudrpa/api/getAccountsForUser");
            getAccountForUserRequest.KeepAlive = false;
            getAccountForUserRequest.ProtocolVersion = HttpVersion.Version10;
            getAccountForUserRequest.Method = "GET";
            getAccountForUserRequest.ContentType = "application/json";
            getAccountForUserRequest.Headers.Add("Authorization", "Bearer " + TokenDict["idToken"]);


            HttpWebResponse myHttpWebResponse = (HttpWebResponse)getAccountForUserRequest.GetResponse();
            if (myHttpWebResponse.StatusCode == HttpStatusCode.OK)
            {
                StreamReader httpWebStreamReader = new StreamReader(getAccountForUserRequest.GetResponse().GetResponseStream());
                String result = httpWebStreamReader.ReadToEnd();
                FileWatcherService.APIJsonResponse = result;




                using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(FileWatcherService.APIJsonResponse)))
                {
                    // Deserialization from JSON  
                    DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(Account));
                    Account bsObj2 = (Account)deserializer.ReadObject(ms);

                    FileWatcherService.AccountForUserDict.Add("accountName", bsObj2.accounts[0].accountName);
                    FileWatcherService.AccountForUserDict.Add("accountLogicalName", bsObj2.accounts[0].accountLogicalName);



                }
                getAccountForUserRequest.GetResponse().Close();
                httpWebStreamReader.Close();

            }

        }
    }
}

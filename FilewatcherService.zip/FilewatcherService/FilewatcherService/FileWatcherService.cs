﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Dynamic;
using System.Net.Http;
using System.Net;
using System.Runtime.Serialization.Json;
using Newtonsoft.Json;
using System.Web;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Timers;

namespace FilewatcherService
{
    public partial class FileWatcherService : ServiceBase
    {
        public FileWatcherService()
        {
            InitializeComponent();
   
        }

        //Global components
        public static string propFilePath;
        public static string Orchestrator_Login_URL;
        public static string requestBody;
        public static string Client_Id;
        public static string Refresh_token;
        public static string APIJsonResponse;
        public static string ReleaseKey;
        public static string Process_Name;
        public static string Environment_Name;
        public static string Is_Cloud_Platform;
        public static string Tenant_Name;
        public static string UserNameorEmail;
        public static string password;
        public static string Is_Queue_Trigger_Enabled;
        public static string Is_Queue_Addition_Enabled;
        public static string Queue_Name;
        public static string filePath;
        public static dynamic PropertyFile;
        public static FileSystemWatcher watcher = new FileSystemWatcher();

        //Global Dictionary Variables
        public static Dictionary<String, String> TokenDict = new Dictionary<string, string> { };
        public static Dictionary<String, String> AccountForUserDict = new Dictionary<string, string> { };
        public static Dictionary<String, String> ServiceAccountDetails = new Dictionary<string, string> { };
        public static Dictionary<String, String> ReleaseKeyDict = new Dictionary<string, string> { };

        protected override void OnStart(string[] args)
        {
            try
            {
                if (args.Length == 0)
                {
                    throw (new Exception("No Arguments Provided"));
                }
                else
                {
                    BeginWatching(args);
                }
                
            }
            catch (Exception sysexcptn)
            {
                EventLog.WriteEntry(sysexcptn.Message);
            }
            
        }
       

        private static void BeginWatching(string[] args)
        {
            try
            {
                filePath = "";

                propFilePath = args[0];

                PropertyFile = new ReadOnlyFile(args[0]);
                foreach (string line in PropertyFile.Orchestrator_Login_URL)
                {
                    Orchestrator_Login_URL = line.Split(',')[1].Trim();
                }
                foreach (string line in PropertyFile.Tenant_Name)
                {
                    Tenant_Name = line.Split(',')[1].Trim();
                }
                foreach (string line in PropertyFile.UserNameorEmail)
                {
                    UserNameorEmail = line.Split(',')[1].Trim();
                }
                foreach (string line in PropertyFile.Password)
                {
                    password = line.Split(',')[1].Trim();
                }
                foreach (string line in PropertyFile.Watcher_Folder)
                {
                    filePath = line.Split(',')[1].Trim();
                }

                foreach (string line in PropertyFile.Client_Id)
                {
                    Client_Id = line.Split(',')[1].Trim();
                   
                }
                foreach (string line in PropertyFile.refresh_token)
                {
                    Refresh_token = line.Split(',')[1].Trim();
                }
                foreach (string line in PropertyFile.ReleaseKey)
                {
                    ReleaseKey = line.Split(',')[1].Trim();
                }
                foreach (string line in PropertyFile.Process_Name)
                {
                    Process_Name = line.Split(',')[1].Trim();
                }
                foreach (string line in PropertyFile.Environment_Name)
                {
                    Environment_Name = line.Split(',')[1].Trim();
                }
                foreach (string line in PropertyFile.Is_Cloud_Platform)
                {
                    Is_Cloud_Platform = line.Split(',')[1].Trim();
                }
                foreach (string line in PropertyFile.Is_Queue_Trigger_Enabled)
                {
                    Is_Queue_Trigger_Enabled = line.Split(',')[1].Trim();
                }
                foreach (string line in PropertyFile.Is_Queue_Addition_Enabled)
                {
                    Is_Queue_Addition_Enabled = line.Split(',')[1].Trim();
                }
                foreach (string line in PropertyFile.Queue_Name)
                {
                    Queue_Name = line.Split(',')[1].Trim();
                }

               

               Run(filePath, PropertyFile);
            }
            catch(Exception sysexc)
            {
                
                throw (sysexc);
            }
        }

        private static void Run(String filePath, dynamic prop)
        {
           
            
                watcher.Path = filePath;
                EventLog eventlog = new EventLog();
                eventlog.Source = "FilewatcherInfo_Run";
               
                eventlog.WriteEntry("Watching for any changes for path-- > " + filePath);
                
                watcher.NotifyFilter = NotifyFilters.LastAccess
                                     | NotifyFilters.LastWrite
                                     | NotifyFilters.FileName
                                     | NotifyFilters.DirectoryName;


                foreach (string line in prop.file_Filters)
                {

                    watcher.Filter = line.Split(',')[1].Trim();
                }
                
                eventlog.WriteEntry(watcher.Filter);
               
                
                watcher.Created += OnChanged;
                //watcher.Deleted += OnChanged;
                //watcher.Renamed += OnRenamed;
                watcher.EnableRaisingEvents = true;
            
         }

       
        
        protected override void OnStop()
        {
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace FilewatcherService
{
    class OnPremiseToken
    {

        public  void GetOnPremiseAccessToken()
        {
            String OnPremiseAccessTokeRequesturi = FileWatcherService.Orchestrator_Login_URL.Trim() + "/api/Account/Authenticate";

            HttpWebRequest OnPremiseAccessTokeRequest = (HttpWebRequest)WebRequest.Create(OnPremiseAccessTokeRequesturi);
            //HttpUtility.UrlDecode(ReleaseKeyRequest.Address.AbsoluteUri);
            OnPremiseAccessTokeRequest.KeepAlive = false;
            OnPremiseAccessTokeRequest.ProtocolVersion = HttpVersion.Version10;
            OnPremiseAccessTokeRequest.Method = "POST";
            OnPremiseAccessTokeRequest.ContentType = "application/json";

            FileWatcherService.requestBody = string.Format("{{\"tenancyName\":\"{0}\",\"usernameOrEmailAddress\":\"{1}\",\"password\":\"{2}\"}}", FileWatcherService.Tenant_Name, FileWatcherService.UserNameorEmail, FileWatcherService.password);
            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] byte1 = encoding.GetBytes(FileWatcherService.requestBody);
            OnPremiseAccessTokeRequest.ContentLength = byte1.Length;
            Stream newStream = OnPremiseAccessTokeRequest.GetRequestStream();
            newStream.Write(byte1, 0, byte1.Length);
            try
            {
                HttpWebResponse myHttpWebResponse = (HttpWebResponse)OnPremiseAccessTokeRequest.GetResponse();
                if (myHttpWebResponse.StatusCode == HttpStatusCode.OK)
                {

                    StreamReader httpWebStreamReader = new StreamReader(OnPremiseAccessTokeRequest.GetResponse().GetResponseStream());
                    String result = httpWebStreamReader.ReadToEnd();
                    FileWatcherService.APIJsonResponse = result;
                    using (var ms = new MemoryStream(Encoding.Unicode.GetBytes(FileWatcherService.APIJsonResponse)))
                    {
                        // Deserialization from JSON  
                        DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(OnPremiseAccessToken));
                        OnPremiseAccessToken bsObj2 = (OnPremiseAccessToken)deserializer.ReadObject(ms);


                        FileWatcherService.TokenDict.Add("accessToken", bsObj2.result);



                    }
                    OnPremiseAccessTokeRequest.GetResponse().Close();
                    httpWebStreamReader.Close();
                }
            }
            catch(System.Exception sysexcptn)
            {
                throw  new Exception(sysexcptn.Message+"::On Premise Orchestrator UserId/TenantName/Password incorrect");
            }



        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace FilewatcherService
{
    class AllService
    {
        public  void GetAllServiceAccount(Dictionary<String, String> AccountForUserDict, Dictionary<String, String> TokenDict)
        {
            HttpWebRequest GetServiceAccountRequest = (System.Net.HttpWebRequest)WebRequest.Create(FileWatcherService.Orchestrator_Login_URL.Trim() + "/cloudrpa/api/account/" + AccountForUserDict["accountLogicalName"] + "/getAllServiceInstances");
            GetServiceAccountRequest.KeepAlive = false;
            GetServiceAccountRequest.ProtocolVersion = HttpVersion.Version10;
            GetServiceAccountRequest.Method = "GET";
            GetServiceAccountRequest.ContentType = "application/json";
            GetServiceAccountRequest.Headers.Add("Authorization", "Bearer " + TokenDict["idToken"]);

           
            HttpWebResponse myHttpWebResponse = (HttpWebResponse)GetServiceAccountRequest.GetResponse();
            if (myHttpWebResponse.StatusCode == HttpStatusCode.OK)
            {
                StreamReader httpWebStreamReader = new StreamReader(GetServiceAccountRequest.GetResponse().GetResponseStream());
                String result = httpWebStreamReader.ReadToEnd();
                FileWatcherService.APIJsonResponse = result;

                ServiceInstanceResult service = JsonConvert.DeserializeObject<ServiceInstanceResult>(FileWatcherService.APIJsonResponse);
                FileWatcherService.ServiceAccountDetails.Add("serviceInstanceName", service.ser.serviceInstanceName);
                FileWatcherService.ServiceAccountDetails.Add("serviceInstanceLogicalName", service.ser.serviceInstanceLogicalName);
                GetServiceAccountRequest.GetResponse().Close();
                httpWebStreamReader.Close();
            }

        }
    }
}
